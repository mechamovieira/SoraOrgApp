import { useState, useCallback, useMemo } from 'react';
import { ActivityType, MemberStatus, EventStatus, EventResult } from '../types';
import type { Member, GuildEvent, ActivityLog, Complaint, Team } from '../types';
import { generateId } from '../lib/utils';

export const useGuildData = () => {
  const [members, setMembers] = useState<Member[]>([]);
  const [events, setEvents] = useState<GuildEvent[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityLog[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);

  const addActivity = useCallback((type: ActivityType, description: string) => {
    const newActivity: ActivityLog = {
      id: generateId(),
      date: new Date().toISOString(),
      type,
      description,
    };
    setActivityLog(prev => [newActivity, ...prev]);
  }, []);

  const saveMember = useCallback((memberData: Omit<Member, 'id' | 'complaintsMade' | 'complaintsReceived' | 'infractions'> & { id?: string, complaintsMade?: string[], complaintsReceived?: string[], infractions?: any[] }) => {
    let activityToLog: { type: ActivityType, description: string } | null = null;
    
    if (memberData.id) { // Update existing member
      setMembers(prevMembers => {
        const memberToUpdate = prevMembers.find(m => m.id === memberData.id);
        if (memberToUpdate && memberToUpdate.status !== MemberStatus.Left && memberData.status === MemberStatus.Left) {
            activityToLog = { type: ActivityType.MemberLeft, description: `${memberData.nickname} saiu da guilda. Motivo: ${memberData.exitReason || 'Não especificado'}` };
        } else {
            activityToLog = { type: ActivityType.MemberUpdated, description: `Os dados de ${memberData.nickname} foram atualizados.` };
        }
        return prevMembers.map(m => m.id === memberData.id ? { ...m, ...memberData, id: memberData.id } : m);
      });
      // Log activity after members state is set
      if (activityToLog) {
        addActivity(activityToLog.type, activityToLog.description);
      }

    } else { // Add new member
      const newId = generateId();
      const newMember: Member = {
        ...memberData,
        id: newId,
        infractions: memberData.infractions || [], // New members start with no infractions
        complaintsMade: memberData.complaintsMade || [], // Initialize
        complaintsReceived: memberData.complaintsReceived || [], // Initialize
      };
      setMembers(prevMembers => [newMember, ...prevMembers]); // Update members state first
      addActivity(ActivityType.MemberJoined, `${newMember.nickname} entrou na guilda como ${newMember.role}.`); // Log activity
    }
  }, [addActivity]);
  
  const deleteMember = useCallback((memberId: string) => {
    const memberToDelete = members.find(m => m.id === memberId);
    if (!memberToDelete) {
        console.error("Member to delete not found:", memberId);
        return;
    }

    addActivity(ActivityType.MemberLeft, `${memberToDelete.nickname} foi removido(a) permanentemente da guilda.`);
    
    // Remove member from any events
    setEvents(prevEvents => 
        prevEvents.map(event => ({
            ...event,
            participantIds: event.participantIds.filter(id => id !== memberId),
            organizerIds: event.organizerIds.filter(id => id !== memberId),
        }))
    );
    
    // Also remove member from any teams
    setTeams(prevTeams => prevTeams.map(team => ({
        ...team,
        memberIds: team.memberIds.filter(id => id !== memberId),
        // If the deleted member was the captain, set captain to null or first member
        captainId: team.captainId === memberId ? (team.memberIds.filter(id => id !== memberId)[0] || '') : team.captainId
    })));

    setMembers(prevMembers => prevMembers.filter(m => m.id !== memberId));

  }, [addActivity, members]);


  const saveEvent = useCallback((eventData: Omit<GuildEvent, 'id'> & { id?: string }) => {
    setEvents(prevEvents => {
        if (eventData.id) { // Update
            addActivity(ActivityType.EventCompleted, `Evento "${eventData.name}" foi atualizado.`);
            return prevEvents.map(e => e.id === eventData.id ? { ...e, ...eventData, id: e.id } : e);
        } else { // Create
            const newEvent: GuildEvent = {
                ...eventData,
                id: generateId(),
                organizerIds: [],
                participantIds: [],
            };
            addActivity(ActivityType.EventCreated, `Novo evento criado: ${newEvent.name}.`);
            return [newEvent, ...prevEvents];
        }
    });
  }, [addActivity]);
  
  const saveComplaint = useCallback((complaintData: Omit<Complaint, 'id' | 'date'>) => {
    const newComplaint: Complaint = {
        ...complaintData,
        id: generateId(),
        date: new Date().toISOString(),
    };

    setComplaints(prev => [newComplaint, ...prev]);

    setMembers(prevMembers => {
        const reporter = prevMembers.find(m => m.id === newComplaint.reporterId);
        const accused = prevMembers.find(m => m.id === newComplaint.accusedId);

        if (!reporter || !accused) return prevMembers; 

        addActivity(ActivityType.ComplaintFiled, `Denúncia registrada por ${reporter.nickname} contra ${accused.nickname}.`);

        return prevMembers.map(m => {
            if (m.id === reporter.id) {
                return { ...m, complaintsMade: [...m.complaintsMade, newComplaint.description] };
            }
            if (m.id === accused.id) {
                return { ...m, complaintsReceived: [...m.complaintsReceived, newComplaint.description] };
            }
            return m;
        });
    });
  }, [addActivity]);
  
  const saveTeam = useCallback((teamData: Omit<Team, 'id'> & { id?: string }) => {
    if (teamData.id) { // Update
        setTeams(prev => prev.map(t => t.id === teamData.id ? { ...t, ...teamData, id: t.id } : t));
        addActivity(ActivityType.TeamUpdated, `Time "${teamData.name}" foi atualizado.`);
    } else { // Create
        const newTeam = { ...teamData, id: generateId() };
        setTeams(prev => [newTeam, ...prev]);
        addActivity(ActivityType.TeamCreated, `Time "${newTeam.name}" foi criado.`);
    }
  }, [addActivity]);

  const deleteTeam = useCallback((teamId: string) => {
    const teamToDelete = teams.find(t => t.id === teamId);
    if (teamToDelete) {
        setTeams(prev => prev.filter(t => t.id !== teamId));
        addActivity(ActivityType.TeamUpdated, `Time "${teamToDelete.name}" foi dissolvido.`);
    }
  }, [addActivity, teams]);

  const membersWithAttendance = useMemo(() => {
    const completedEvents = events.filter(event => event.status === EventStatus.Completed);
    const totalRelevantEvents = completedEvents.length;

    return members.map(member => {
      const attendedEventsCount = completedEvents.filter(event => 
        event.participantIds.includes(member.id)
      ).length;
      
      const percentage = totalRelevantEvents > 0
        ? Math.round((attendedEventsCount / totalRelevantEvents) * 100)
        : 0;

      return { ...member, attendancePercentage: percentage };
    });
  }, [members, events]);
  
  const teamsWithStats = useMemo(() => {
    return teams.map(team => {
        const wins = events.filter(e => e.participatingTeamId === team.id && e.result === EventResult.Victory).length;
        const losses = events.filter(e => e.participatingTeamId === team.id && e.result === EventResult.Defeat).length;
        return { ...team, wins, losses };
    });
  }, [teams, events]);

  const sortedActivityLog = useMemo(() => {
      return [...activityLog].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [activityLog]);
  
  const sortedComplaints = useMemo(() => {
    return [...complaints].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [complaints]);

  return {
    members: membersWithAttendance,
    events,
    teams: teamsWithStats,
    activityLog: sortedActivityLog,
    complaints: sortedComplaints,
    saveMember,
    deleteMember,
    saveEvent,
    saveComplaint,
    saveTeam,
    deleteTeam,
  };
};