import { Member, GuildEvent, ActivityLog, Lane, MemberStatus, EventType, EventStatus, ActivityType, MemberRole, Complaint, Team, EventResult } from '../types';

export const MOCK_MEMBERS: Member[] = [
  {
    id: '1',
    fullName: 'Carlos Andrade',
    nickname: 'ShadowBlade',
    role: MemberRole.Founder,
    mainLane: Lane.Mid,
    secondaryLane: Lane.Top,
    characters: ['Yasuo', 'Zed', 'Akali'],
    discordNick: 'ShadowBlade#1234',
    contact: 'Discord',
    birthDate: '1995-03-15',
    joinDate: '2022-01-10',
    status: MemberStatus.Active,
    infractions: [],
    complaintsMade: ["IronTank esteve AFK durante o treino de 2023-08-10."],
    complaintsReceived: [],
    notes: 'Fundador da guilda.'
  },
  {
    id: '2',
    fullName: 'Juliana Souza',
    nickname: 'LunarArrow',
    role: MemberRole.Administrator,
    mainLane: Lane.ADC,
    secondaryLane: Lane.Support,
    characters: ['Ashe', 'Caitlyn', 'Jinx'],
    discordNick: 'LunarArrow#5678',
    contact: 'WhatsApp',
    birthDate: '1998-07-22',
    joinDate: '2022-02-20',
    status: MemberStatus.Active,
    infractions: [],
    complaintsMade: [],
    complaintsReceived: [],
  },
  {
    id: '3',
    fullName: 'Ricardo Lima',
    nickname: 'IronTank',
    role: MemberRole.Member,
    mainLane: Lane.Top,
    characters: ['Garen', 'Darius', 'Ornn'],
    discordNick: 'IronTank#9012',
    contact: 'Discord',
    birthDate: '1997-11-05',
    joinDate: '2022-03-01',
    status: MemberStatus.Active,
    infractions: [
      { id: 'inf1', date: '2023-05-10', description: 'Atraso em 3 treinos seguidos.' }
    ],
    complaintsMade: [],
    complaintsReceived: ["Esteve AFK durante o treino de 2023-08-10."],
  },
  {
    id: '4',
    fullName: 'Fernanda Costa',
    nickname: 'MysticSong',
    role: MemberRole.Member,
    mainLane: Lane.Support,
    characters: ['Soraka', 'Lulu', 'Janna'],
    discordNick: 'MysticSong#3456',
    contact: 'Discord',
    birthDate: '2000-01-30',
    joinDate: '2023-06-15',
    status: MemberStatus.Inactive,
    infractions: [],
    complaintsMade: [],
    complaintsReceived: [],
    notes: 'Pausa para estudos.'
  },
    {
    id: '5',
    fullName: 'Bruno Gomes',
    nickname: 'JungleKing',
    role: MemberRole.Member,
    mainLane: Lane.Jungle,
    secondaryLane: Lane.Flex,
    characters: ['Lee Sin', 'Vi', 'Kha\'Zix'],
    discordNick: 'JungleKing#7890',
    contact: 'Discord',
    birthDate: '1999-09-12',
    joinDate: '2022-04-18',
    status: MemberStatus.Active,
    infractions: [],
    complaintsMade: [],
    complaintsReceived: [],
  },
  {
    id: '6',
    fullName: 'Alice Pereira',
    nickname: 'FallenAngel',
    role: MemberRole.Member,
    mainLane: Lane.Mid,
    characters: ['Lux', 'Ahri'],
    discordNick: 'FallenAngel#1122',
    contact: 'N/A',
    birthDate: '1996-05-25',
    joinDate: '2022-01-15',
    status: MemberStatus.Left,
    exitReason: 'Mudou para outra guilda.',
    exitDate: '2023-01-20',
    infractions: [],
    complaintsMade: ['Fez reclamação sobre o líder do evento X'],
    complaintsReceived: [],
  },
];

export const MOCK_TEAMS: Team[] = [
  {
    id: 't1',
    name: 'Esquadrão Trovão',
    captainId: '1',
    memberIds: ['1', '2', '3', '5', '4']
  },
  {
    id: 't2',
    name: 'Fênix Renegada',
    captainId: '2',
    memberIds: ['2', '5']
  }
];


export const MOCK_EVENTS: GuildEvent[] = [
  {
    id: 'e1',
    name: 'Treino de Sinergia (Bot Lane)',
    date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // 2 days ago
    type: EventType.Training,
    description: 'Foco em 2v2 e controle de wave.',
    status: EventStatus.Completed,
    organizerIds: ['1'],
    participantIds: ['2', '4', '5'],
    participatingTeamId: 't1',
    result: EventResult.Victory,
  },
  {
    id: 'e2',
    name: 'Scrim vs Guilda Rival',
    date: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // in 3 days
    type: EventType.Scrim,
    description: 'Série MD3. Line-up principal.',
    status: EventStatus.Planned,
    organizerIds: [],
    participantIds: [],
  },
  {
    id: 'e3',
    name: 'Reunião de Planejamento',
    date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // in 7 days
    type: EventType.Meeting,
    description: 'Discutir estratégias para o próximo torneio.',
    status: EventStatus.Planned,
    organizerIds: [],
    participantIds: [],
  },
];

export const MOCK_COMPLAINTS: Complaint[] = [
  {
    id: 'c1',
    date: '2023-08-11T14:00:00Z',
    reporterId: '1',
    accusedId: '3',
    description: 'Esteve AFK durante o treino de 2023-08-10.'
  }
];

export const MOCK_ACTIVITY_LOG: ActivityLog[] = [
    { id: 'a-1', date: '2023-08-12T10:00:00Z', type: ActivityType.TeamCreated, description: 'Time "Esquadrão Trovão" foi criado.' },
    { id: 'a0', date: '2023-08-11T14:00:00Z', type: ActivityType.ComplaintFiled, description: 'Denúncia registrada por ShadowBlade contra IronTank.' },
    { id: 'a1', date: '2023-06-15T10:00:00Z', type: ActivityType.MemberJoined, description: 'MysticSong entrou na guilda como Membro.' },
    { id: 'a2', date: '2023-05-10T18:00:00Z', type: ActivityType.MemberUpdated, description: 'Infração registrada para IronTank.' },
    { id: 'a3', date: '2023-04-01T20:00:00Z', type: ActivityType.EventCompleted, description: 'O evento "Torneio de Abertura" foi concluído.' },
    { id: 'a4', date: '2023-03-01T14:00:00Z', type: ActivityType.MemberJoined, description: 'IronTank entrou na guilda como Membro.' },
];