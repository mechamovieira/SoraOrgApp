import React, { useState } from 'react';
import { Header } from './components/Header';
import { MemberView } from './components/MemberView';
import { EventView } from './components/EventView';
import { ComplaintView } from './components/ComplaintView';
import { TeamView } from './components/TeamView';
import { DashboardView } from './components/DashboardView';
import { SettingsView } from './components/SettingsView'; // New
import { useGuildData } from './hooks/useGuildData';
import type { Page } from './types';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('Dashboard');
  const guildData = useGuildData();

  const renderContent = () => {
    switch (currentPage) {
      case 'Dashboard':
        return <DashboardView members={guildData.members} events={guildData.events} teams={guildData.teams} activityLog={guildData.activityLog} />;
      case 'Membros':
        return <MemberView {...guildData} />;
      case 'Eventos':
        return <EventView members={guildData.members} events={guildData.events} teams={guildData.teams} saveEvent={guildData.saveEvent} />;
      case 'Times':
        return <TeamView members={guildData.members} teams={guildData.teams} saveTeam={guildData.saveTeam} deleteTeam={guildData.deleteTeam} />;
      case 'Denúncias':
        return <ComplaintView members={guildData.members} complaints={guildData.complaints} saveComplaint={guildData.saveComplaint} />;
      case 'Configurações':
        return <SettingsView />;
      default:
        return <DashboardView members={guildData.members} events={guildData.events} teams={guildData.teams} activityLog={guildData.activityLog} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 font-sans">
      <Header currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="p-4 sm:p-6 lg:p-8">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;