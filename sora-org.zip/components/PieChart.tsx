import React from 'react';

interface PieChartProps {
  data: { label: string; value: number }[];
  title: string;
  colors: string[];
}

const PieSlice: React.FC<{
  color: string;
  percentage: number;
  startAngle: number;
  endAngle: number;
}> = ({ color, startAngle, endAngle }) => {
  const radius = 85;
  const largeArcFlag = endAngle - startAngle <= 180 ? '0' : '1';

  const startX = radius * Math.cos((startAngle * Math.PI) / 180);
  const startY = radius * Math.sin((startAngle * Math.PI) / 180);
  const endX = radius * Math.cos((endAngle * Math.PI) / 180);
  const endY = radius * Math.sin((endAngle * Math.PI) / 180);

  const d = [
    `M ${startX} ${startY}`,
    `A ${radius} ${radius} 0 ${largeArcFlag} 1 ${endX} ${endY}`,
    'L 0 0',
  ].join(' ');

  return <path d={d} fill={color} />;
};

export const PieChart: React.FC<PieChartProps> = ({ data, title, colors }) => {
  const total = data.reduce((acc, item) => acc + item.value, 0);

  if (total === 0) {
    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg h-full flex flex-col">
            <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
            <div className="flex-grow flex items-center justify-center">
                <p className="text-gray-400">Nenhum dado para exibir.</p>
            </div>
        </div>
    );
  }

  let cumulativeAngle = 0;

  return (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg h-full flex flex-col">
      <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
      <div className="flex flex-col md:flex-row items-center justify-center gap-6 flex-grow">
        <div className="relative w-48 h-48">
          <svg viewBox="-100 -100 200 200" transform="rotate(-90)">
            {data.map((item, index) => {
              const percentage = (item.value / total) * 100;
              const angle = (percentage / 100) * 360;
              const startAngle = cumulativeAngle;
              cumulativeAngle += angle;
              const endAngle = cumulativeAngle;

              return (
                <PieSlice
                  key={item.label}
                  color={colors[index % colors.length]}
                  percentage={percentage}
                  startAngle={startAngle}
                  endAngle={endAngle}
                />
              );
            })}
          </svg>
        </div>
        <div className="flex flex-col gap-2">
          {data.map((item, index) => (
            <div key={item.label} className="flex items-center gap-2">
              <div
                className="w-4 h-4 rounded-sm"
                style={{ backgroundColor: colors[index % colors.length] }}
              />
              <span className="text-gray-300 text-sm">
                {item.label}: {item.value} (
                {((item.value / total) * 100).toFixed(1)}%)
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};