import React, { useState, useEffect, useCallback } from 'react';
import type { Member, Infraction } from '../types';
import { Lane, MemberStatus, MemberRole } from '../types';
import { Modal } from './Modal';
import { generateId } from '../lib/utils'; // Import generateId

interface MemberFormProps {
  member: Member | null;
  onSave: (member: Omit<Member, 'id'> & { id?: string }) => void;
  onClose: () => void;
  onDelete: (memberId: string) => void;
}

const initialFormState: Omit<Member, 'id' | 'infractions' | 'complaintsMade' | 'complaintsReceived'> = {
  fullName: '',
  nickname: '',
  role: MemberRole.Member, // Default role
  mainLane: Lane.Flex,
  characters: [],
  discordNick: '',
  contact: '',
  birthDate: '',
  joinDate: new Date().toISOString().split('T')[0],
  status: MemberStatus.Active,
  exitReason: '',
  exitDate: '', // New field
  notes: ''
};

export const MemberForm: React.FC<MemberFormProps> = ({ member, onSave, onClose, onDelete }) => {
  const [formData, setFormData] = useState<Partial<Member & { newInfractionDescription?: string }>>(initialFormState);
  const [charInput, setCharInput] = useState('');
  const [newInfractionDescription, setNewInfractionDescription] = useState('');

  useEffect(() => {
    if (member) {
      setFormData({
        fullName: member.fullName,
        nickname: member.nickname,
        role: member.role,
        mainLane: member.mainLane,
        secondaryLane: member.secondaryLane,
        characters: member.characters,
        discordNick: member.discordNick,
        contact: member.contact,
        birthDate: member.birthDate,
        joinDate: member.joinDate,
        status: member.status,
        exitReason: member.exitReason || '',
        exitDate: member.exitDate || '', // Populate new field
        infractions: member.infractions,
        complaintsMade: member.complaintsMade || [], // Populate new field
        complaintsReceived: member.complaintsReceived || [], // Populate new field
        notes: member.notes || ''
      });
    } else {
        setFormData(initialFormState);
    }
  }, [member]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleAddCharacter = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && charInput.trim() !== '') {
      e.preventDefault();
      setFormData(prev => ({...prev, characters: [...(prev.characters || []), charInput.trim()]}));
      setCharInput('');
    }
  }

  const handleRemoveCharacter = (charToRemove: string) => {
    setFormData(prev => ({...prev, characters: (prev.characters || []).filter(c => c !== charToRemove)}));
  }

  const handleAddInfraction = () => {
    if (newInfractionDescription.trim() !== '') {
      const newInfraction: Infraction = {
        id: generateId(),
        date: new Date().toISOString().split('T')[0],
        description: newInfractionDescription.trim(),
      };
      setFormData(prev => ({
        ...prev,
        infractions: [...(prev.infractions || []), newInfraction],
      }));
      setNewInfractionDescription('');
    }
  };

  const handleRemoveInfraction = (idToRemove: string) => {
    setFormData(prev => ({
      ...prev,
      infractions: (prev.infractions || []).filter(inf => inf.id !== idToRemove),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const submissionData = { ...formData };
    if (submissionData.secondaryLane === '') {
        delete (submissionData as Partial<Member>).secondaryLane;
    }
    // Remove exitDate if status is not 'Left'
    if (submissionData.status !== MemberStatus.Left) {
      delete (submissionData as Partial<Member>).exitDate;
      delete (submissionData as Partial<Member>).exitReason;
    }
    // Type assertion to satisfy onSave prop
    onSave({ ...submissionData, id: member?.id } as Omit<Member, 'id'> & { id?: string });
    onClose();
  };

  const handleDelete = useCallback(() => {
    if (member && window.confirm(`Tem certeza que deseja excluir ${member.nickname}? Esta ação não pode ser desfeita.`)) {
        onDelete(member.id);
        onClose();
    }
  }, [member, onDelete, onClose]);
  
  const formTitle = member ? `Editar ${member.nickname}` : 'Adicionar Novo Membro';

  return (
    <Modal title={formTitle} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <InputField label="Nome Completo" name="fullName" value={formData.fullName || ''} onChange={handleChange} required />
            <InputField label="Nickname no Jogo" name="nickname" value={formData.nickname || ''} onChange={handleChange} required />
            <SelectField label="Cargo/Função" name="role" value={formData.role || MemberRole.Member} onChange={handleChange} options={Object.values(MemberRole)} />
            <SelectField label="Lane Principal" name="mainLane" value={formData.mainLane || Lane.Flex} onChange={handleChange} options={Object.values(Lane)} />
            <div>
                <label htmlFor="secondaryLane" className="block text-sm font-medium text-gray-300">Lane Secundária</label>
                <select id="secondaryLane" name="secondaryLane" value={formData.secondaryLane || ''} onChange={handleChange} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary">
                    <option value="">Nenhuma</option>
                    {Object.values(Lane).map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
            </div>
            <InputField label="Nickname no Discord" name="discordNick" value={formData.discordNick || ''} onChange={handleChange} />
            <InputField label="Contato (WhatsApp, etc.)" name="contact" value={formData.contact || ''} onChange={handleChange} />
            <InputField label="Data de Nascimento" name="birthDate" type="date" value={formData.birthDate || ''} onChange={handleChange} />
            <InputField label="Data de Entrada" name="joinDate" type="date" value={formData.joinDate || ''} onChange={handleChange} required />
        </div>
        
        {/* Characters (Mains) */}
        <div>
            <label className="block text-sm font-medium text-gray-300">Personagens (Mains)</label>
            <div className="flex flex-wrap gap-2 mt-1 p-2 bg-gray-700 rounded-md border border-gray-600">
                {(formData.characters || []).map(char => (
                    <span key={char} className="flex items-center gap-1 bg-primary text-white px-2 py-1 rounded-full text-xs">
                        {char}
                        <button type="button" onClick={() => handleRemoveCharacter(char)} className="text-white hover:text-gray-200">&times;</button>
                    </span>
                ))}
            </div>
            <input type="text"
                value={charInput}
                onChange={(e) => setCharInput(e.target.value)}
                onKeyDown={handleAddCharacter}
                placeholder="Digite o nome e aperte Enter"
                className="w-full mt-2 bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary" />
        </div>

        <SelectField label="Situação" name="status" value={formData.status || MemberStatus.Active} onChange={handleChange} options={Object.values(MemberStatus)} />
        {formData.status === MemberStatus.Left && (
            <>
                <InputField label="Motivo da Saída" name="exitReason" value={formData.exitReason || ''} onChange={handleChange} />
                <InputField label="Data de Saída" name="exitDate" type="date" value={formData.exitDate || ''} onChange={handleChange} />
            </>
        )}
        <TextAreaField label="Anotações Gerais" name="notes" value={formData.notes || ''} onChange={handleChange} />

        {/* Infractions UI */}
        <div>
          <label className="block text-sm font-medium text-gray-300">Advertências</label>
          <div className="space-y-2 mt-1 p-2 bg-gray-700 rounded-md border border-gray-600 max-h-48 overflow-y-auto">
            {(formData.infractions || []).length === 0 && <p className="text-gray-400 text-sm">Nenhuma advertência registrada.</p>}
            {(formData.infractions || []).map(inf => (
              <div key={inf.id} className="flex justify-between items-center bg-gray-600 p-2 rounded-md">
                <span className="text-sm text-gray-200">{inf.date}: {inf.description}</span>
                <button type="button" onClick={() => handleRemoveInfraction(inf.id)} className="text-gray-400 hover:text-white text-lg font-bold">&times;</button>
              </div>
            ))}
          </div>
          <div className="flex gap-2 mt-2">
            <input
              type="text"
              value={newInfractionDescription}
              onChange={(e) => setNewInfractionDescription(e.target.value)}
              placeholder="Adicionar nova advertência"
              className="flex-grow bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <button
              type="button"
              onClick={handleAddInfraction}
              className="py-2 px-4 bg-primary hover:bg-primary-hover rounded-md text-white font-semibold transition-colors"
            >
              Adicionar
            </button>
          </div>
        </div>

        {/* Complaints Made UI */}
        <div>
            <label className="block text-sm font-medium text-gray-300">Denúncias Feitas</label>
            <div className="space-y-2 mt-1 p-2 bg-gray-700 rounded-md border border-gray-600 max-h-32 overflow-y-auto">
                {(formData.complaintsMade || []).length === 0 
                  ? <p className="text-gray-400 text-sm">Nenhuma denúncia feita.</p>
                  : (formData.complaintsMade || []).map((complaint, index) => (
                    <div key={index} className="bg-blue-600/30 text-blue-200 p-2 rounded-md text-sm">
                        {complaint}
                    </div>
                ))}
            </div>
        </div>

        {/* Complaints Received UI */}
        <div>
            <label className="block text-sm font-medium text-gray-300">Denúncias Recebidas</label>
            <div className="space-y-2 mt-1 p-2 bg-gray-700 rounded-md border border-gray-600 max-h-32 overflow-y-auto">
                {(formData.complaintsReceived || []).length === 0
                  ? <p className="text-gray-400 text-sm">Nenhuma denúncia recebida.</p>
                  : (formData.complaintsReceived || []).map((complaint, index) => (
                    <div key={index} className="bg-red-600/30 text-red-200 p-2 rounded-md text-sm">
                        {complaint}
                    </div>
                ))}
            </div>
        </div>

        <div className="flex justify-between items-center gap-4 pt-4">
            <div>
                {member && (
                    <button 
                        type="button" 
                        onClick={handleDelete} 
                        className="py-2 px-4 bg-danger hover:bg-red-400 rounded-md text-white font-semibold transition-colors"
                    >
                        Excluir Membro
                    </button>
                )}
            </div>
            <div className="flex gap-4">
              <button type="button" onClick={onClose} className="py-2 px-4 bg-gray-600 hover:bg-gray-500 rounded-md text-white font-semibold transition-colors">Cancelar</button>
              <button type="submit" className="py-2 px-4 bg-primary hover:bg-primary-hover rounded-md text-white font-semibold transition-colors">Salvar</button>
            </div>
        </div>
      </form>
    </Modal>
  );
};


// Helper sub-components for form fields
const InputField: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, type?: string, required?: boolean}> = ({ label, name, value, onChange, type = 'text', required = false}) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300">{label}</label>
        <input type={type} name={name} id={name} value={value} onChange={onChange} required={required} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary" />
    </div>
);

const SelectField: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void, options: string[]}> = ({ label, name, value, onChange, options }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300">{label}</label>
        <select id={name} name={name} value={value} onChange={onChange} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary">
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    </div>
);

const TextAreaField: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void}> = ({ label, name, value, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300">{label}</label>
        <textarea id={name} name={name} value={value} onChange={onChange} rows={3} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"></textarea>
    </div>
);