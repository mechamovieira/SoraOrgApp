import React, { useState } from 'react';
import type { Member, Complaint } from '../types';
import { Modal } from './Modal';
import { MemberStatus } from '../types';

interface ComplaintFormProps {
  members: Member[];
  onSave: (complaint: Omit<Complaint, 'id' | 'date'>) => void;
  onClose: () => void;
}

export const ComplaintForm: React.FC<ComplaintFormProps> = ({ members, onSave, onClose }) => {
  const [reporterId, setReporterId] = useState('');
  const [accusedId, setAccusedId] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');

  const activeMembers = members.filter(m => m.status === MemberStatus.Active);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reporterId || !accusedId || !description.trim()) {
      setError('Todos os campos são obrigatórios.');
      return;
    }
    if (reporterId === accusedId) {
      setError('O denunciante e o denunciado não podem ser a mesma pessoa.');
      return;
    }
    
    onSave({
      reporterId,
      accusedId,
      description,
    });
    onClose();
  };

  return (
    <Modal title="Registrar Nova Denúncia" onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="reporterId" className="block text-sm font-medium text-gray-300">Denunciante</label>
          <select
            id="reporterId"
            value={reporterId}
            onChange={(e) => setReporterId(e.target.value)}
            className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary"
            required
          >
            <option value="" disabled>Selecione um membro</option>
            {activeMembers.map(member => (
              <option key={member.id} value={member.id}>{member.nickname}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="accusedId" className="block text-sm font-medium text-gray-300">Denunciado</label>
          <select
            id="accusedId"
            value={accusedId}
            onChange={(e) => setAccusedId(e.target.value)}
            className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary"
            required
          >
            <option value="" disabled>Selecione um membro</option>
            {activeMembers.map(member => (
              <option key={member.id} value={member.id}>{member.nickname}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="description" className="block text-sm font-medium text-gray-300">Descrição</label>
          <textarea
            id="description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={4}
            className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
            required
          />
        </div>

        {error && <p className="text-sm text-danger">{error}</p>}

        <div className="flex justify-end gap-4 pt-4">
          <button type="button" onClick={onClose} className="py-2 px-4 bg-gray-600 hover:bg-gray-500 rounded-md text-white font-semibold transition-colors">
            Cancelar
          </button>
          <button type="submit" className="py-2 px-4 bg-primary hover:bg-primary-hover rounded-md text-white font-semibold transition-colors">
            Registrar Denúncia
          </button>
        </div>
      </form>
    </Modal>
  );
};
