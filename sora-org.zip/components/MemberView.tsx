import React, { useState, useMemo, useRef, useEffect } from 'react';
import type { Member, Lane, MemberStatus } from '../types';
import { MemberStatus as MemberStatusEnum, Lane as LaneEnum } from '../types';
import { MemberForm } from './MemberForm';
import { AddIcon, FilterIcon, ClearIcon, SearchIcon } from './icons';

interface MemberViewProps {
  members: (Member & { attendancePercentage: number })[];
  saveMember: (member: Omit<Member, 'id' | 'complaintsMade' | 'complaintsReceived' | 'infractions'> & { id?: string, complaintsMade?: string[], complaintsReceived?: string[], infractions?: any[] }) => void;
  deleteMember: (memberId: string) => void;
}

const statusColors: Record<MemberStatus, string> = {
  [MemberStatusEnum.Active]: 'bg-green-500/20 text-green-400',
  [MemberStatusEnum.Inactive]: 'bg-yellow-500/20 text-yellow-400',
  [MemberStatusEnum.Left]: 'bg-red-500/20 text-red-400',
};

const laneColors: Record<Lane, string> = {
  [LaneEnum.Top]: 'bg-red-600/30 text-red-300',
  [LaneEnum.Jungle]: 'bg-green-600/30 text-green-300',
  [LaneEnum.Mid]: 'bg-purple-600/30 text-purple-300',
  [LaneEnum.ADC]: 'bg-blue-600/30 text-blue-300',
  [LaneEnum.Support]: 'bg-yellow-600/30 text-yellow-300',
  [LaneEnum.Flex]: 'bg-gray-500/30 text-gray-300',
};

const initialFilterState = {
    status: 'All',
    generalLane: 'All',
    mainLane: 'All',
    secondaryLane: 'All',
    search: '',
};

export const MemberView: React.FC<MemberViewProps> = ({ members, saveMember, deleteMember }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [showSearch, setShowSearch] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [filters, setFilters] = useState(initialFilterState);

  useEffect(() => {
    if (showSearch && searchInputRef.current) {
        searchInputRef.current.focus();
    }
  }, [showSearch]);

  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => {
        const newFilters = { ...prev, [name]: value };
        // If user selects a general lane, disable specific lane filters
        if (name === 'generalLane' && value !== 'All') {
            newFilters.mainLane = 'All';
            newFilters.secondaryLane = 'All';
        }
        // If user selects a specific lane, disable general lane filter
        if ((name === 'mainLane' || name === 'secondaryLane') && value !== 'All') {
            newFilters.generalLane = 'All';
        }
        return newFilters;
    });
  };

  const handleClearFilters = () => {
    setFilters(prev => ({ ...initialFilterState, search: prev.search }));
  };
  
  const filteredMembers = useMemo(() => {
    const filtered = members.filter(member => {
        const statusMatch = filters.status === 'All' || member.status === filters.status;
        const searchMatch = filters.search === '' ||
            member.nickname.toLowerCase().includes(filters.search.toLowerCase()) ||
            member.fullName.toLowerCase().includes(filters.search.toLowerCase());

        const generalLaneMatch = filters.generalLane === 'All' ||
            member.mainLane === filters.generalLane ||
            member.secondaryLane === filters.generalLane;
        
        const mainLaneMatch = filters.mainLane === 'All' || member.mainLane === filters.mainLane;
        const secondaryLaneMatch = filters.secondaryLane === 'All' || member.secondaryLane === filters.secondaryLane;

        return statusMatch && searchMatch && generalLaneMatch && mainLaneMatch && secondaryLaneMatch;
    });

    if (filters.generalLane !== 'All') {
        filtered.sort((a, b) => {
            const aIsMain = a.mainLane === filters.generalLane;
            const bIsMain = b.mainLane === filters.generalLane;
            if (aIsMain && !bIsMain) return -1;
            if (!aIsMain && bIsMain) return 1;
            return 0;
        });
    }

    return filtered;
  }, [members, filters]);


  const openFormForEdit = (member: Member) => {
    setSelectedMember(member);
    setIsFormOpen(true);
  };

  const openFormForNew = () => {
    setSelectedMember(null);
    setIsFormOpen(true);
  };

  const selectClassName = "bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed";


  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-white">Gerenciamento de Membros</h1>
        <div className="flex items-center gap-2">
            <button
                onClick={openFormForNew}
                className="flex items-center justify-center gap-2 bg-primary hover:bg-primary-hover text-white font-bold py-2 px-4 rounded-lg transition-colors"
            >
                <AddIcon />
                Adicionar Membro
            </button>
            <button
                onClick={() => setShowFilters(!showFilters)}
                className="p-2 bg-gray-600 hover:bg-gray-500 text-white font-bold rounded-lg transition-colors"
                aria-label="Filtros"
            >
                <FilterIcon />
            </button>
            <button
                onClick={() => setShowSearch(!showSearch)}
                className="p-2 bg-gray-600 hover:bg-gray-500 text-white font-bold rounded-lg transition-colors"
                aria-label="Buscar"
            >
                <SearchIcon />
            </button>
        </div>
      </div>
      
      {showSearch && (
        <div className="mt-2">
            <input 
                ref={searchInputRef}
                type="text"
                name="search"
                placeholder="Buscar por nome ou nick..."
                value={filters.search}
                onChange={handleFilterChange}
                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
            />
        </div>
      )}

      {showFilters && (
        <div className="bg-gray-800 p-4 rounded-lg space-y-4">
            <div className="flex flex-wrap gap-4 items-center">
                <select name="status" value={filters.status} onChange={handleFilterChange} className={selectClassName}>
                    <option value="All">Todos os Status</option>
                    {Object.values(MemberStatusEnum).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
                <select name="generalLane" value={filters.generalLane} onChange={handleFilterChange} className={selectClassName}>
                    <option value="All">Lane Geral</option>
                    {Object.values(LaneEnum).map(l => <option key={l} value={l}>{l}</option>)}
                </select>
                <select name="mainLane" value={filters.mainLane} onChange={handleFilterChange} disabled={filters.generalLane !== 'All'} className={selectClassName}>
                    <option value="All">Lane Principal</option>
                    {Object.values(LaneEnum).map(l => <option key={l} value={l}>{l}</option>)}
                </select>
                <select name="secondaryLane" value={filters.secondaryLane} onChange={handleFilterChange} disabled={filters.generalLane !== 'All'} className={selectClassName}>
                    <option value="All">Lane Secundária</option>
                    {Object.values(LaneEnum).map(l => <option key={l} value={l}>{l}</option>)}
                </select>
            </div>
            <div className="flex justify-end">
                <button
                    onClick={handleClearFilters}
                    className="flex items-center justify-center gap-2 bg-danger hover:bg-red-400 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm"
                >
                    <ClearIcon />
                    Limpar Filtros
                </button>
            </div>
        </div>
      )}

      <div className="overflow-x-auto bg-gray-800 rounded-lg shadow-md">
        <table className="min-w-full divide-y divide-gray-700">
          <thead className="bg-gray-700/50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Nickname</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider hidden md:table-cell">Cargo</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Lane</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Presença</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider hidden sm:table-cell">Status</th>
              <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {filteredMembers.map(member => (
              <tr key={member.id} className="hover:bg-gray-700/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="text-sm font-medium text-white">{member.nickname}</div>
                    <div className="text-xs text-gray-400 ml-2 md:hidden">({member.role})</div>
                  </div>
                  <div className="text-sm text-gray-400 hidden sm:block">{member.fullName}</div>
                   <div className="text-xs text-gray-400 sm:hidden mt-1">
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[member.status]}`}>
                            {member.status}
                        </span>
                    </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300 hidden md:table-cell">{member.role}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-1 flex-wrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${laneColors[member.mainLane]}`}>
                      {member.mainLane}
                    </span>
                    {member.secondaryLane && (
                       <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${laneColors[member.secondaryLane]}`}>
                        {member.secondaryLane}
                      </span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <div className="flex items-center gap-2">
                     <div className="w-20 bg-gray-600 rounded-full h-2.5">
                        <div className="bg-primary h-2.5 rounded-full" style={{ width: `${member.attendancePercentage}%` }}></div>
                    </div>
                    <span className="text-white">{member.attendancePercentage}%</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap hidden sm:table-cell">
                  <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColors[member.status]}`}>
                    {member.status}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => openFormForEdit(member)} className="text-primary hover:text-primary-hover">Editar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {isFormOpen && (
        <MemberForm
          member={selectedMember}
          onSave={saveMember}
          onClose={() => setIsFormOpen(false)}
          onDelete={deleteMember}
        />
      )}
    </div>
  );
};