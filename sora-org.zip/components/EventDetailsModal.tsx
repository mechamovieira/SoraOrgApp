
import React from 'react';
import type { GuildEvent, Member, Team } from '../types';
import { EventStatus } from '../types';
import { Modal } from './Modal';
import { EditIcon } from './icons';

interface EventDetailsModalProps {
  event: GuildEvent;
  members: Member[];
  teams: Team[];
  onClose: () => void;
  onEdit: (event: GuildEvent) => void;
}

const AttendanceList: React.FC<{ title: string; memberIds: string[]; membersMap: Map<string, string> }> = ({ title, memberIds, membersMap }) => (
    <div>
        <h4 className="text-md font-semibold text-gray-200 mb-2">{title}</h4>
        {memberIds.length > 0 ? (
            <ul className="list-disc list-inside text-gray-300 space-y-1">
                {memberIds.map(id => (
                    <li key={id}>{membersMap.get(id) || 'Membro desconhecido'}</li>
                ))}
            </ul>
        ) : (
            <p className="text-sm text-gray-400">Nenhum membro selecionado.</p>
        )}
    </div>
);


export const EventDetailsModal: React.FC<EventDetailsModalProps> = ({ event, members, teams, onClose, onEdit }) => {
    
    const membersMap = new Map(members.map(m => [m.id, m.nickname]));
    const participatingTeam = event.participatingTeamId ? teams.find(t => t.id === event.participatingTeamId) : null;

    return (
        <Modal title={event.name} onClose={onClose}>
            <div className="space-y-4">
                <div className="flex justify-between items-start">
                    <div>
                        <p className="text-gray-400">{new Date(event.date).toLocaleString('pt-BR', { dateStyle: 'long', timeStyle: 'short' })}</p>
                        <p className="text-gray-300">{event.description}</p>
                         <div className="flex items-center gap-2 mt-2 flex-wrap">
                            <span className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${event.status === EventStatus.Completed ? 'bg-secondary' : 'bg-gray-600'}`}>
                                {event.status}
                            </span>
                             {participatingTeam && (
                                <span className="inline-block px-2 py-1 text-xs font-semibold rounded-full bg-blue-500/20 text-blue-300">
                                    Time: {participatingTeam.name}
                                </span>
                            )}
                            {event.result && (
                                <span className={`inline-block px-2 py-1 text-xs font-semibold rounded-full ${event.result === 'Vitória' ? 'bg-green-500/20 text-green-300' : 'bg-red-500/20 text-red-300'}`}>
                                    {event.result}
                                </span>
                            )}
                         </div>
                    </div>
                     <button onClick={() => onEdit(event)} className="flex items-center gap-2 text-sm text-primary hover:text-primary-hover p-2 rounded-lg hover:bg-gray-700 transition-colors">
                        <EditIcon /> Editar
                    </button>
                </div>

                <div className="bg-gray-700/50 p-4 rounded-lg">
                    <h3 className="text-lg font-semibold mb-3 text-white border-b border-gray-600 pb-2">Lista de Presença</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <AttendanceList title="Organizadores" memberIds={event.organizerIds} membersMap={membersMap} />
                        <AttendanceList title="Participantes" memberIds={event.participantIds} membersMap={membersMap} />
                    </div>
                </div>

                 <div className="flex justify-end pt-4">
                    <button onClick={onClose} className="py-2 px-4 bg-primary hover:bg-primary-hover rounded-md text-white font-semibold transition-colors">Fechar</button>
                </div>
            </div>
        </Modal>
    );
};