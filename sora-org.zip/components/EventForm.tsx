
import React, { useState, useEffect } from 'react';
import type { GuildEvent, Team, Member } from '../types';
import { EventType, EventStatus, EventResult, MemberStatus } from '../types';
import { Modal } from './Modal';

interface EventFormProps {
  event: GuildEvent | null;
  teams: Team[];
  members: Member[];
  onSave: (event: Omit<GuildEvent, 'id'> & { id?: string }) => void;
  onClose: () => void;
}

const initialFormState: Omit<GuildEvent, 'id'> = {
  name: '',
  date: new Date().toISOString().slice(0, 16),
  type: EventType.Other,
  description: '',
  status: EventStatus.Planned,
  participatingTeamId: '',
  result: undefined,
  organizerIds: [],
  participantIds: [],
};

const MemberSelection: React.FC<{
    title: string;
    members: Member[];
    selectedIds: string[];
    onSelect: (memberId: string) => void;
}> = ({ title, members, selectedIds, onSelect }) => (
    <div>
        <label className="block text-sm font-medium text-gray-300">{title}</label>
        <div className="mt-2 p-3 bg-gray-700 rounded-md border border-gray-600 max-h-40 overflow-y-auto grid grid-cols-2 md:grid-cols-3 gap-2">
            {members.map(member => (
                <label key={member.id} className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-600 transition-colors cursor-pointer">
                    <input 
                        type="checkbox"
                        checked={selectedIds.includes(member.id)}
                        onChange={() => onSelect(member.id)}
                        className="h-4 w-4 rounded border-gray-500 bg-gray-600 text-primary focus:ring-primary"
                    />
                    <span className="text-gray-200 text-sm">{member.nickname}</span>
                </label>
            ))}
            {members.length === 0 && <p className="text-sm text-gray-400 col-span-full">Nenhum membro ativo para selecionar.</p>}
        </div>
    </div>
);


export const EventForm: React.FC<EventFormProps> = ({ event, teams, members, onSave, onClose }) => {
  const [formData, setFormData] = useState(initialFormState);

  useEffect(() => {
    if (event) {
      setFormData({
        name: event.name,
        date: event.date.slice(0,16),
        type: event.type,
        description: event.description,
        status: event.status,
        participatingTeamId: event.participatingTeamId || '',
        result: event.result,
        organizerIds: event.organizerIds || [],
        participantIds: event.participantIds || [],
      });
    } else {
        setFormData(initialFormState);
    }
  }, [event]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleAttendanceChange = (memberId: string, type: 'organizer' | 'participant') => {
    setFormData(prev => {
        const isOrganizer = prev.organizerIds.includes(memberId);
        const isParticipant = prev.participantIds.includes(memberId);
        let newOrganizers = [...prev.organizerIds];
        let newParticipants = [...prev.participantIds];

        if (type === 'organizer') {
            if (isOrganizer) {
                newOrganizers = newOrganizers.filter(id => id !== memberId);
            } else {
                newOrganizers.push(memberId);
                if (isParticipant) newParticipants = newParticipants.filter(id => id !== memberId); // Remove from other list
            }
        } else { // participant
             if (isParticipant) {
                newParticipants = newParticipants.filter(id => id !== memberId);
            } else {
                newParticipants.push(memberId);
                if (isOrganizer) newOrganizers = newOrganizers.filter(id => id !== memberId); // Remove from other list
            }
        }
        return { ...prev, organizerIds: newOrganizers, participantIds: newParticipants };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const submissionData = { ...formData };

    // Clean up team/result fields if not a relevant event type
    if (submissionData.type !== EventType.Scrim && submissionData.type !== EventType.Training) {
        delete submissionData.participatingTeamId;
        delete submissionData.result;
    }
     // Clean up result if event is not completed
    if (submissionData.status !== EventStatus.Completed) {
        delete submissionData.result;
    }

    onSave({ ...submissionData, id: event?.id, date: new Date(formData.date).toISOString() });
    onClose();
  };
  
  const formTitle = event ? `Editar Evento: ${event.name}` : 'Criar Novo Evento';
  const activeMembers = members.filter(m => m.status === MemberStatus.Active);

  return (
    <Modal title={formTitle} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <InputField label="Nome do Evento" name="name" value={formData.name} onChange={handleChange} required />
        <InputField label="Data e Hora" name="date" type="datetime-local" value={formData.date} onChange={handleChange} required />
        <SelectField label="Tipo de Evento" name="type" value={formData.type} onChange={handleChange} options={Object.values(EventType)} />
        <SelectField label="Status do Evento" name="status" value={formData.status} onChange={handleChange} options={Object.values(EventStatus)} />
        
        {(formData.type === EventType.Scrim || formData.type === EventType.Training) && (
            <div className="p-4 bg-gray-700/50 rounded-lg space-y-4 border-l-4 border-primary">
                 <h3 className="font-semibold text-white">Detalhes da Partida</h3>
                 <SelectField 
                    label="Time Participante" 
                    name="participatingTeamId" 
                    value={formData.participatingTeamId || ''} 
                    onChange={handleChange} 
                    options={teams.map(t => ({ value: t.id, label: t.name }))}
                    includeEmptyOption={true}
                />

                {formData.status === EventStatus.Completed && (
                     <SelectField 
                        label="Resultado" 
                        name="result" 
                        value={formData.result || ''} 
                        onChange={handleChange} 
                        options={Object.values(EventResult)}
                        includeEmptyOption={true}
                    />
                )}
            </div>
        )}

        <TextAreaField label="Descrição" name="description" value={formData.description} onChange={handleChange} />
        
        <div className="space-y-4 pt-2">
            <h3 className="font-semibold text-white border-b border-gray-600 pb-2">Lista de Presença</h3>
            <MemberSelection 
                title="Organizadores"
                members={activeMembers}
                selectedIds={formData.organizerIds}
                onSelect={(memberId) => handleAttendanceChange(memberId, 'organizer')}
            />
            <MemberSelection 
                title="Participantes"
                members={activeMembers}
                selectedIds={formData.participantIds}
                onSelect={(memberId) => handleAttendanceChange(memberId, 'participant')}
            />
        </div>


        <div className="flex justify-end gap-4 pt-4">
          <button type="button" onClick={onClose} className="py-2 px-4 bg-gray-600 hover:bg-gray-500 rounded-md text-white font-semibold transition-colors">Cancelar</button>
          <button type="submit" className="py-2 px-4 bg-primary hover:bg-primary-hover rounded-md text-white font-semibold transition-colors">Salvar Evento</button>
        </div>
      </form>
    </Modal>
  );
};


// Helper sub-components for form fields
const InputField: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLInputElement>) => void, type?: string, required?: boolean}> = ({ label, name, value, onChange, type = 'text', required = false}) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300">{label}</label>
        <input type={type} name={name} id={name} value={value} onChange={onChange} required={required} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary" />
    </div>
);

type SelectOption = string | { value: string; label: string };

const SelectField: React.FC<{
  label: string;
  name: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  options: SelectOption[];
  includeEmptyOption?: boolean;
}> = ({ label, name, value, onChange, options, includeEmptyOption = false }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300">{label}</label>
        <select id={name} name={name} value={value} onChange={onChange} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary">
            {includeEmptyOption && <option value="">Selecione...</option>}
            {options.map(opt => {
                const optionValue = typeof opt === 'string' ? opt : opt.value;
                const optionLabel = typeof opt === 'string' ? opt : opt.label;
                return <option key={optionValue} value={optionValue}>{optionLabel}</option>;
            })}
        </select>
    </div>
);

const TextAreaField: React.FC<{label: string, name: string, value: string, onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void}> = ({ label, name, value, onChange }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-300">{label}</label>
        <textarea id={name} name={name} value={value} onChange={onChange} rows={3} className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"></textarea>
    </div>
);