import React, { useState, useEffect } from 'react';
import type { Member, Team } from '../types';
import { Modal } from './Modal';
import { MemberStatus } from '../types';

interface TeamFormProps {
  team: Team | null;
  members: Member[];
  onSave: (team: Omit<Team, 'id'> & { id?: string }) => void;
  onClose: () => void;
  onDelete: (teamId: string) => void;
}

const initialFormState: Omit<Team, 'id'> = {
  name: '',
  captainId: '',
  memberIds: [],
};

export const TeamForm: React.FC<TeamFormProps> = ({ team, members, onSave, onClose, onDelete }) => {
  const [formData, setFormData] = useState(initialFormState);

  useEffect(() => {
    if (team) {
      setFormData(team);
    } else {
      setFormData(initialFormState);
    }
  }, [team]);
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleMemberSelect = (memberId: string) => {
    setFormData(prev => {
        const newMemberIds = prev.memberIds.includes(memberId)
            ? prev.memberIds.filter(id => id !== memberId)
            : [...prev.memberIds, memberId];
        // If the captain is removed from members, reset captain field
        const newCaptainId = newMemberIds.includes(prev.captainId) ? prev.captainId : '';
        return { ...prev, memberIds: newMemberIds, captainId: newCaptainId };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ ...formData, id: team?.id });
    onClose();
  };
  
  const handleDelete = () => {
    if (team && window.confirm(`Tem certeza de que deseja excluir o time "${team.name}"?`)) {
        onDelete(team.id);
        onClose();
    }
  };

  const formTitle = team ? `Editar Time: ${team.name}` : 'Criar Novo Time';
  const activeMembers = members.filter(m => m.status === MemberStatus.Active);
  const selectedMembersForCaptain = activeMembers.filter(m => formData.memberIds.includes(m.id));

  return (
    <Modal title={formTitle} onClose={onClose}>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
            <label htmlFor="name" className="block text-sm font-medium text-gray-300">Nome do Time</label>
            <input type="text" name="name" id="name" value={formData.name} onChange={handleChange} required className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary" />
        </div>
        
        <div>
            <label className="block text-sm font-medium text-gray-300">Membros do Time</label>
            <div className="mt-2 p-3 bg-gray-700 rounded-md border border-gray-600 max-h-48 overflow-y-auto grid grid-cols-2 md:grid-cols-3 gap-2">
                {activeMembers.map(member => (
                    <label key={member.id} className="flex items-center space-x-2 p-2 rounded-md hover:bg-gray-600 transition-colors cursor-pointer">
                        <input 
                            type="checkbox"
                            checked={formData.memberIds.includes(member.id)}
                            onChange={() => handleMemberSelect(member.id)}
                            className="h-4 w-4 rounded border-gray-500 bg-gray-600 text-primary focus:ring-primary"
                        />
                        <span className="text-gray-200 text-sm">{member.nickname}</span>
                    </label>
                ))}
            </div>
        </div>

        <div>
            <label htmlFor="captainId" className="block text-sm font-medium text-gray-300">Capitão</label>
            <select id="captainId" name="captainId" value={formData.captainId} onChange={handleChange} required className="mt-1 block w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50" disabled={formData.memberIds.length === 0}>
                <option value="" disabled>Selecione um capitão</option>
                {selectedMembersForCaptain.map(member => (
                    <option key={member.id} value={member.id}>{member.nickname}</option>
                ))}
            </select>
        </div>

        <div className="flex justify-between items-center gap-4 pt-4">
            <div>
                {team && (
                    <button 
                        type="button" 
                        onClick={handleDelete} 
                        className="py-2 px-4 bg-danger hover:bg-red-400 rounded-md text-white font-semibold transition-colors"
                    >
                        Excluir Time
                    </button>
                )}
            </div>
            <div className="flex gap-4">
              <button type="button" onClick={onClose} className="py-2 px-4 bg-gray-600 hover:bg-gray-500 rounded-md text-white font-semibold transition-colors">Cancelar</button>
              <button type="submit" className="py-2 px-4 bg-primary hover:bg-primary-hover rounded-md text-white font-semibold transition-colors">Salvar</button>
            </div>
        </div>
      </form>
    </Modal>
  );
};
