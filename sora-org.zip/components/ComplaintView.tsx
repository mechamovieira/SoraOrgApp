import React, { useState, useMemo } from 'react';
import type { Complaint, Member } from '../types';
import { ComplaintForm } from './ComplaintForm';
import { AddIcon } from './icons';

interface ComplaintViewProps {
  complaints: Complaint[];
  members: Member[];
  saveComplaint: (complaint: Omit<Complaint, 'id' | 'date'>) => void;
}

export const ComplaintView: React.FC<ComplaintViewProps> = ({ complaints, members, saveComplaint }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);

  const memberMap = useMemo(() => {
    const map = new Map<string, string>();
    members.forEach(member => {
      map.set(member.id, member.nickname);
    });
    return map;
  }, [members]);

  const getNickname = (id: string) => memberMap.get(id) || 'Membro Desconhecido';

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-white">Gerenciamento de Denúncias</h1>
        <button
          onClick={() => setIsFormOpen(true)}
          className="w-full md:w-auto flex items-center justify-center gap-2 bg-primary hover:bg-primary-hover text-white font-bold py-2 px-4 rounded-lg transition-colors"
        >
          <AddIcon />
          Registrar Denúncia
        </button>
      </div>

      <div className="bg-gray-800 rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Data
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Denunciante
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Denunciado
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">
                  Descrição
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-700">
              {complaints.map((complaint) => (
                <tr key={complaint.id} className="hover:bg-gray-700/50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-400">
                    {new Date(complaint.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                    {getNickname(complaint.reporterId)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-white">
                    {getNickname(complaint.accusedId)}
                  </td>
                  <td className="px-6 py-4 text-sm text-gray-300 max-w-md">
                    <p className="truncate" title={complaint.description}>{complaint.description}</p>
                  </td>
                </tr>
              ))}
              {complaints.length === 0 && (
                <tr>
                  <td colSpan={4} className="text-center py-8 text-gray-400">
                    Nenhuma denúncia registrada.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isFormOpen && (
        <ComplaintForm
          members={members}
          onSave={saveComplaint}
          onClose={() => setIsFormOpen(false)}
        />
      )}
    </div>
  );
};
