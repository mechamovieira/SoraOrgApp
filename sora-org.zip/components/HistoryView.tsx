import React, { useMemo } from 'react';
import type { ActivityLog, Member, GuildEvent } from '../types';
import { EventType, ActivityType, MemberStatus } from '../types';

interface HistoryViewProps {
  activityLog: ActivityLog[];
  members: (Member & { attendancePercentage: number })[];
  events: GuildEvent[];
}

const activityTypeIcons: Record<ActivityType, string> = {
    [ActivityType.MemberJoined]: '👤+',
    [ActivityType.MemberLeft]: '👤-',
    [ActivityType.EventCreated]: '🗓️+',
    [ActivityType.EventCompleted]: '✅',
    [ActivityType.MemberUpdated]: '✏️',
    [ActivityType.ComplaintFiled]: '🚩',
    [ActivityType.TeamCreated]: '🛡️+',
    [ActivityType.TeamUpdated]: '🛡️✏️',
};

const activityTypeColors: Record<ActivityType, string> = {
    [ActivityType.MemberJoined]: 'bg-green-500/20 text-green-400',
    [ActivityType.MemberLeft]: 'bg-red-500/20 text-red-400',
    [ActivityType.EventCreated]: 'bg-blue-500/20 text-blue-400',
    [ActivityType.EventCompleted]: 'bg-purple-500/20 text-purple-400',
    [ActivityType.MemberUpdated]: 'bg-yellow-500/20 text-yellow-400',
    [ActivityType.ComplaintFiled]: 'bg-orange-500/20 text-orange-400',
    [ActivityType.TeamCreated]: 'bg-teal-500/20 text-teal-400',
    [ActivityType.TeamUpdated]: 'bg-indigo-500/20 text-indigo-400',
};


export const HistoryView: React.FC<HistoryViewProps> = ({ activityLog, members, events }) => {
    
    const stats = useMemo(() => {
        const activeMembers = members.filter(m => m.status === MemberStatus.Active);
        const mostActiveMembers = [...activeMembers].sort((a, b) => b.attendancePercentage - a.attendancePercentage).slice(0, 3);
        const eventCountByType = events.reduce((acc, event) => {
            acc[event.type] = (acc[event.type] || 0) + 1;
            return acc;
        }, {} as Record<EventType, number>);

        return {
            totalMembers: members.length,
            activeMembersCount: activeMembers.length,
            mostActiveMembers,
            eventCountByType
        }
    }, [members, events]);

    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-white mb-6">Estatísticas e Histórico</h1>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <StatCard title="Total de Membros" value={stats.totalMembers.toString()} />
                    <StatCard title="Membros Ativos" value={stats.activeMembersCount.toString()} />
                    <div className="bg-gray-800 p-6 rounded-lg col-span-1 md:col-span-2">
                        <h3 className="text-lg font-semibold text-gray-200">Eventos por Tipo</h3>
                        <div className="mt-4 flex flex-wrap gap-4">
                            {Object.entries(stats.eventCountByType).map(([type, count]) => (
                                <div key={type} className="text-center">
                                    <p className="text-2xl font-bold text-primary">{count}</p>
                                    <p className="text-sm text-gray-400">{type}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                 <div className="mt-6 bg-gray-800 p-6 rounded-lg">
                    <h3 className="text-lg font-semibold text-gray-200 mb-4">Membros Mais Ativos (Presença)</h3>
                    <div className="space-y-3">
                        {stats.mostActiveMembers.map(member => (
                            <div key={member.id} className="flex items-center justify-between">
                                <span className="text-white font-medium">{member.nickname}</span>
                                <div className="flex items-center gap-2 w-1/2">
                                    <div className="w-full bg-gray-600 rounded-full h-2.5">
                                        <div className="bg-primary h-2.5 rounded-full" style={{ width: `${member.attendancePercentage}%` }}></div>
                                    </div>
                                    <span className="text-sm text-gray-300 w-12 text-right">{member.attendancePercentage}%</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>

            <div>
                <h2 className="text-2xl font-bold text-white mb-4">Histórico de Atividades</h2>
                <div className="bg-gray-800 rounded-lg shadow-md max-h-96 overflow-y-auto">
                    <ul className="divide-y divide-gray-700">
                        {activityLog.map(log => (
                            <li key={log.id} className="p-4 flex items-start space-x-4">
                               <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold ${activityTypeColors[log.type]}`}>
                                    {activityTypeIcons[log.type]}
                                </div>
                                <div>
                                    <p className="text-sm text-white">{log.description}</p>
                                    <p className="text-xs text-gray-400 mt-1">{new Date(log.date).toLocaleString()}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

const StatCard: React.FC<{ title: string; value: string }> = ({ title, value }) => (
  <div className="bg-gray-800 p-6 rounded-lg text-center">
    <p className="text-4xl font-bold text-primary">{value}</p>
    <p className="mt-2 text-sm font-semibold text-gray-400 uppercase tracking-wider">{title}</p>
  </div>
);