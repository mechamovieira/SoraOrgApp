import React, { useState } from 'react';

// A reusable section component for styling consistency
const SettingsSection: React.FC<{ title: string; children: React.ReactNode; danger?: boolean }> = ({ title, children, danger = false }) => (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-lg ${danger ? 'border border-danger' : ''}`}>
        <h2 className={`text-xl font-bold text-white mb-4 pb-2 border-b ${danger ? 'border-danger/50' : 'border-gray-700'}`}>{title}</h2>
        <div className="space-y-4">
            {children}
        </div>
    </div>
);

// A reusable form row component
const FormRow: React.FC<{ label: string; description: string; children: React.ReactNode }> = ({ label, description, children }) => (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
            <h3 className="text-md font-semibold text-gray-200">{label}</h3>
            <p className="text-sm text-gray-400 mt-1 max-w-md">{description}</p>
        </div>
        <div className="mt-2 sm:mt-0 flex-shrink-0">
            {children}
        </div>
    </div>
);

export const SettingsView: React.FC = () => {
    const [guildName, setGuildName] = useState('Sora Org');
    const [isDarkMode, setIsDarkMode] = useState(true);

    const handleExport = () => {
        alert("Funcionalidade de exportação de dados em desenvolvimento.");
    };

    const handleReset = () => {
        if (window.confirm("ATENÇÃO: Esta ação é irreversível e irá apagar TODOS os dados da guilda (membros, eventos, etc.). Deseja continuar?")) {
            alert("Dados da guilda resetados. (Funcionalidade de simulação)");
            // In a real app, you would call a function here to clear localStorage/API data.
        }
    };

    return (
        <div className="space-y-8">
            <h1 className="text-3xl font-bold text-white">Configurações</h1>

            <SettingsSection title="Geral">
                <FormRow
                    label="Nome da Guilda"
                    description="O nome que será exibido em toda a aplicação."
                >
                    <input 
                        type="text" 
                        value={guildName} 
                        onChange={(e) => setGuildName(e.target.value)}
                        className="w-full sm:w-64 bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary"
                    />
                </FormRow>
            </SettingsSection>

            <SettingsSection title="Aparência">
                <FormRow
                    label="Tema Escuro"
                    description="Ative para uma experiência visual mais confortável em ambientes com pouca luz."
                >
                    <label htmlFor="darkModeToggle" className="flex items-center cursor-pointer">
                        <div className="relative">
                            <input type="checkbox" id="darkModeToggle" className="sr-only" checked={isDarkMode} onChange={() => setIsDarkMode(!isDarkMode)} />
                            <div className="block bg-gray-600 w-14 h-8 rounded-full"></div>
                            <div className={`dot absolute left-1 top-1 bg-white w-6 h-6 rounded-full transition ${isDarkMode ? 'transform translate-x-full bg-primary' : ''}`}></div>
                        </div>
                    </label>
                </FormRow>
            </SettingsSection>

            <SettingsSection title="Gerenciamento de Dados">
                <FormRow
                    label="Exportar Dados"
                    description="Faça o download de todos os dados da guilda em formato CSV."
                >
                    <button
                        onClick={handleExport}
                        className="py-2 px-4 bg-secondary/80 hover:bg-secondary rounded-md text-white font-semibold transition-colors"
                    >
                        Exportar
                    </button>
                </FormRow>
            </SettingsSection>

            <SettingsSection title="Zona de Perigo" danger>
                 <FormRow
                    label="Resetar Dados da Guilda"
                    description="Apaga permanentemente todos os membros, eventos e configurações. Use com cuidado."
                >
                    <button
                        onClick={handleReset}
                        className="py-2 px-4 bg-danger hover:bg-red-400 rounded-md text-white font-semibold transition-colors"
                    >
                        Resetar Dados
                    </button>
                </FormRow>
            </SettingsSection>
        </div>
    );
};