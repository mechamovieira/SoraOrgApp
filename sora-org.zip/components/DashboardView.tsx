
import React, { useMemo, useState } from 'react';
import type { Member, GuildEvent, Team, ActivityLog } from '../types';
import { MemberStatus, ActivityType, Lane } from '../types';
import { BarChartIcon, PieChartIcon } from './icons';
import { PieChart } from './PieChart';

// Props interface
interface DashboardViewProps {
  members: (Member & { attendancePercentage: number })[];
  events: GuildEvent[];
  teams: (Team & { wins: number; losses: number; })[];
  activityLog: ActivityLog[];
}

const activityTypeIcons: Record<ActivityType, string> = {
    [ActivityType.MemberJoined]: '👤+',
    [ActivityType.MemberLeft]: '👤-',
    [ActivityType.EventCreated]: '🗓️+',
    [ActivityType.EventCompleted]: '✅',
    [ActivityType.MemberUpdated]: '✏️',
    [ActivityType.ComplaintFiled]: '🚩',
    [ActivityType.TeamCreated]: '🛡️+',
    [ActivityType.TeamUpdated]: '🛡️✏️',
};

const activityTypeColors: Record<ActivityType, string> = {
    [ActivityType.MemberJoined]: 'bg-green-500/20 text-green-400',
    [ActivityType.MemberLeft]: 'bg-red-500/20 text-red-400',
    [ActivityType.EventCreated]: 'bg-blue-500/20 text-blue-400',
    [ActivityType.EventCompleted]: 'bg-purple-500/20 text-purple-400',
    [ActivityType.MemberUpdated]: 'bg-yellow-500/20 text-yellow-400',
    [ActivityType.ComplaintFiled]: 'bg-orange-500/20 text-orange-400',
    [ActivityType.TeamCreated]: 'bg-teal-500/20 text-teal-400',
    [ActivityType.TeamUpdated]: 'bg-indigo-500/20 text-indigo-400',
};


const StatCard: React.FC<{ title: string; value: string | number; subtext?: string }> = ({ title, value, subtext }) => (
    <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
        <p className="text-sm font-semibold text-gray-400 uppercase tracking-wider">{title}</p>
        <p className="text-4xl font-bold text-white mt-2">{value}</p>
        {subtext && <p className="text-xs text-gray-500 mt-1">{subtext}</p>}
    </div>
);

const BarChart: React.FC<{ data: { label: string; value: number }[]; title: string; colorClass: string }> = ({ data, title, colorClass }) => {
    const maxValue = Math.max(...data.map(d => d.value), 1);
    return (
        <div className="bg-gray-800 p-6 rounded-lg shadow-lg h-full">
            <h3 className="text-lg font-semibold text-white mb-4">{title}</h3>
            <div className="space-y-3">
                {data.map(item => (
                    <div key={item.label} className="flex items-center gap-3">
                        <span className="text-sm text-gray-400 w-16 text-right">{item.label}</span>
                        <div className="flex-1 bg-gray-700 rounded-full h-4">
                            <div
                                className={`${colorClass} h-4 rounded-full flex items-center justify-end pr-2`}
                                style={{ width: `${(item.value / maxValue) * 100}%` }}
                            >
                               <span className="text-xs font-bold text-white">{item.value}</span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export const DashboardView: React.FC<DashboardViewProps> = ({ members, events, teams, activityLog }) => {
    const [timeFilter, setTimeFilter] = useState<'30d' | '90d' | 'all'>('30d');
    const [chartType, setChartType] = useState<'bar' | 'pie'>('bar');
    
    const stats = useMemo(() => {
        const now = new Date();
        let startDate = new Date();
        if (timeFilter === '30d') {
            startDate.setDate(now.getDate() - 30);
        } else if (timeFilter === '90d') {
            startDate.setDate(now.getDate() - 90);
        } else {
            startDate = new Date(0); // The beginning of time
        }

        const filteredEvents = events.filter(e => new Date(e.date) >= startDate);
        const filteredMembers = members.filter(m => new Date(m.joinDate) >= startDate);

        const activeMembers = members.filter(m => m.status === MemberStatus.Active);

        const periodWins = filteredEvents.reduce((acc, e) => (e.result === 'Vitória' ? acc + 1 : acc), 0);
        const periodLosses = filteredEvents.reduce((acc, e) => (e.result === 'Derrota' ? acc + 1 : acc), 0);
        const totalMatches = periodWins + periodLosses;
        const winRate = totalMatches > 0 ? Math.round((periodWins / totalMatches) * 100) : 0;

        // FIX: Refactored reduce to forEach to avoid potential type inference issues.
        const statusCounts: Record<string, number> = {};
        members.forEach(member => {
            statusCounts[member.status] = (statusCounts[member.status] || 0) + 1;
        });

        const laneCounts: Record<string, number> = {};
        activeMembers.forEach(member => {
            laneCounts[member.mainLane] = (laneCounts[member.mainLane] || 0) + 1;
        });
        
        const laneDistribution = Object.entries(laneCounts).map(([label, value]) => ({ label, value })).sort((a,b) => b.value - a.value);

        return {
            activeMembersCount: activeMembers.length,
            eventsInPeriod: filteredEvents.length,
            winRateInPeriod: `${winRate}%`,
            newMembersInPeriod: filteredMembers.length,
            statusDistribution: Object.entries(statusCounts).map(([label, value]) => ({ label, value })),
            laneDistribution
        };
    }, [members, events, timeFilter]);

    const upcomingEvents = useMemo(() => {
        const now = new Date();
        return events
            .filter(e => new Date(e.date) >= now && e.status === 'Planejado')
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            .slice(0, 5);
    }, [events]);

    const recentActivities = useMemo(() => {
        return activityLog.slice(0, 5);
    }, [activityLog]);
    
    const chartColors = ["#7C3AED", "#10B981", "#EF4444", "#3B82F6", "#F59E0B", "#6366F1"];


    return (
        <div className="space-y-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
                <h1 className="text-3xl font-bold text-white">Dashboard da Guilda</h1>
                <div className="flex items-center gap-4 bg-gray-800 p-2 rounded-lg">
                   <select 
                        value={timeFilter} 
                        onChange={(e) => setTimeFilter(e.target.value as '30d' | '90d' | 'all')}
                        className="bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:outline-none focus:ring-2 focus:ring-primary"
                    >
                        <option value="30d">Últimos 30 dias</option>
                        <option value="90d">Últimos 90 dias</option>
                        <option value="all">Todo o Período</option>
                    </select>
                </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard title="Membros Ativos" value={stats.activeMembersCount} />
                <StatCard title="Taxa de Vitória" value={stats.winRateInPeriod} subtext={`Período de ${timeFilter === 'all' ? 'Sempre' : timeFilter.replace('d', ' dias')}`} />
                <StatCard title="Eventos no Período" value={stats.eventsInPeriod} />
                <StatCard title="Novos Membros" value={stats.newMembersInPeriod} />
            </div>
            
             <div className="flex justify-end items-center gap-2">
                <span className="text-sm text-gray-400">Tipo de Gráfico:</span>
                <div className="flex items-center bg-gray-700 p-1 rounded-lg">
                    <button onClick={() => setChartType('bar')} className={`p-1 rounded-md transition-colors ${chartType === 'bar' ? 'bg-primary text-white' : 'text-gray-400 hover:bg-gray-600'}`}><BarChartIcon /></button>
                    <button onClick={() => setChartType('pie')} className={`p-1 rounded-md transition-colors ${chartType === 'pie' ? 'bg-primary text-white' : 'text-gray-400 hover:bg-gray-600'}`}><PieChartIcon /></button>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                 {chartType === 'bar' ? (
                    <BarChart data={stats.statusDistribution} title="Distribuição de Membros" colorClass="bg-secondary" />
                ) : (
                    <PieChart data={stats.statusDistribution} title="Distribuição de Membros" colors={chartColors} />
                )}
                 {chartType === 'bar' ? (
                    <BarChart data={stats.laneDistribution} title="Distribuição de Lanes (Ativos)" colorClass="bg-primary" />
                ) : (
                     <PieChart data={stats.laneDistribution} title="Distribuição de Lanes (Ativos)" colors={chartColors} />
                )}
            </div>
            
             <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                 <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                    <h3 className="text-lg font-semibold text-white mb-4">Próximos Eventos</h3>
                    <div className="space-y-3">
                        {upcomingEvents.length > 0 ? upcomingEvents.map(event => (
                            <div key={event.id} className="p-3 bg-gray-700/50 rounded-md">
                                <p className="font-semibold text-white">{event.name}</p>
                                <p className="text-sm text-gray-400">{new Date(event.date).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}</p>
                            </div>
                        )) : <p className="text-gray-400">Nenhum evento futuro agendado.</p>}
                    </div>
                </div>
                <div className="bg-gray-800 p-6 rounded-lg shadow-lg">
                    <h3 className="text-lg font-semibold text-white mb-4">Atividade Recente</h3>
                     <ul className="space-y-2">
                        {recentActivities.map(log => (
                            <li key={log.id} className="flex items-center space-x-3">
                               <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${activityTypeColors[log.type]}`}>
                                    {activityTypeIcons[log.type]}
                                </div>
                                <div>
                                    <p className="text-sm text-gray-200">{log.description}</p>
                                    <p className="text-xs text-gray-500">{new Date(log.date).toLocaleDateString()}</p>
                                </div>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};
