
import React, { useState, useMemo } from 'react';
import type { GuildEvent, Member, Team } from '../types';
import { EventForm } from './EventForm';
import { EventDetailsModal } from './EventDetailsModal';
import { AddIcon } from './icons';
import { EventType, EventStatus } from '../types';

interface EventViewProps {
  events: GuildEvent[];
  members: Member[];
  teams: (Team & { wins: number; losses: number; })[];
  saveEvent: (event: Omit<GuildEvent, 'id'>) => void;
}

const eventTypeColors: Record<EventType, string> = {
    [EventType.Training]: 'bg-blue-500/20 text-blue-300',
    [EventType.Scrim]: 'bg-red-500/20 text-red-300',
    [EventType.Meeting]: 'bg-yellow-500/20 text-yellow-300',
    [EventType.Tournament]: 'bg-purple-500/20 text-purple-300',
    [EventType.Other]: 'bg-gray-500/20 text-gray-300',
};

const eventStatusColors: Record<EventStatus, string> = {
    [EventStatus.Planned]: 'border-l-4 border-primary',
    [EventStatus.Completed]: 'border-l-4 border-secondary',
    [EventStatus.Canceled]: 'border-l-4 border-danger',
};

const EventListItem: React.FC<{ event: GuildEvent; onDetailsClick: (event: GuildEvent) => void; }> = ({ event, onDetailsClick }) => {
  return (
    <div className={`bg-gray-800 p-4 rounded-lg flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 ${eventStatusColors[event.status]}`}>
        <div className="flex-grow">
            <h3 className="font-bold text-white text-lg">{event.name}</h3>
            <p className="text-sm text-gray-400">{new Date(event.date).toLocaleString('pt-BR', { dateStyle: 'long', timeStyle: 'short' })}</p>
        </div>
        <div className="flex items-center gap-4 mt-2 sm:mt-0">
            <span className={`px-3 py-1 text-xs font-semibold rounded-full ${eventTypeColors[event.type]}`}>
                {event.type}
            </span>
             <button
                onClick={() => onDetailsClick(event)}
                className="py-2 px-4 bg-gray-600 hover:bg-gray-500 rounded-md text-white text-sm font-semibold transition-colors"
             >
                Ver Detalhes
             </button>
        </div>
    </div>
  );
};

export const EventView: React.FC<EventViewProps> = ({ events, members, teams, saveEvent }) => {
  const [isEventFormOpen, setIsEventFormOpen] = useState(false);
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);
  
  const [selectedEvent, setSelectedEvent] = useState<GuildEvent | null>(null);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'calendar' | 'list'>('calendar');

  const openEventForm = (event?: GuildEvent) => {
    setSelectedEvent(event || null);
    setIsEventFormOpen(true);
  };

  const openDetailsModal = (event: GuildEvent) => {
    setSelectedEvent(event);
    setIsDetailsModalOpen(true);
  };
  
  // Calendar-specific logic
  const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
  const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  const startDate = new Date(startOfMonth);
  startDate.setDate(startDate.getDate() - startOfMonth.getDay());
  const endDate = new Date(endOfMonth);
  endDate.setDate(endDate.getDate() + (6 - endOfMonth.getDay()));
  
  const days = [];
  let day = new Date(startDate);
  while(day <= endDate) {
    days.push(new Date(day));
    day.setDate(day.getDate() + 1);
  }

  const changeMonth = (offset: number) => {
    setCurrentDate(prev => new Date(prev.getFullYear(), prev.getMonth() + offset, 1));
  };
  
  const isToday = (date: Date) => {
    const today = new Date();
    return date.getDate() === today.getDate() &&
           date.getMonth() === today.getMonth() &&
           date.getFullYear() === today.getFullYear();
  };
  
  // List-view specific logic
  const { upcomingEvents, pastEvents } = useMemo(() => {
    const now = new Date();
    // Ensure correct date objects for comparison
    const upcoming = events.filter(e => new Date(e.date) >= now);
    const past = events.filter(e => new Date(e.date) < now);

    // Sort upcoming events from soonest to latest
    upcoming.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
    // Sort past events from most recent to oldest
    past.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    
    return { upcomingEvents: upcoming, pastEvents: past };
  }, [events]);


  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <div className="flex items-center gap-4">
            <h1 className="text-3xl font-bold text-white">Eventos</h1>
            <div className="flex items-center gap-2 bg-gray-700 p-1 rounded-lg">
                <button onClick={() => setViewMode('calendar')} className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${viewMode === 'calendar' ? 'bg-primary text-white' : 'text-gray-300 hover:bg-gray-600'}`}>Calendário</button>
                <button onClick={() => setViewMode('list')} className={`px-3 py-1 text-sm font-medium rounded-md transition-colors ${viewMode === 'list' ? 'bg-primary text-white' : 'text-gray-300 hover:bg-gray-600'}`}>Lista</button>
            </div>
        </div>
        <button
          onClick={() => openEventForm()}
          className="w-full md:w-auto flex items-center justify-center gap-2 bg-primary hover:bg-primary-hover text-white font-bold py-2 px-4 rounded-lg transition-colors"
        >
          <AddIcon />
          Criar Evento
        </button>
      </div>

      {viewMode === 'calendar' ? (
        <div className="bg-gray-800 p-4 rounded-lg">
          <div className="flex justify-between items-center mb-4">
            <button onClick={() => changeMonth(-1)} className="px-4 py-2 bg-gray-700 rounded-lg hover:bg-gray-600">&lt;</button>
            <h2 className="text-xl font-semibold text-white">
              {currentDate.toLocaleString('default', { month: 'long' })} {currentDate.getFullYear()}
            </h2>
            <button onClick={() => changeMonth(1)} className="px-4 py-2 bg-gray-700 rounded-lg hover:bg-gray-600">&gt;</button>
          </div>
          
          <div className="grid grid-cols-7 gap-1 text-center font-semibold text-gray-400 mb-2">
              <div>Dom</div><div>Seg</div><div>Ter</div><div>Qua</div><div>Qui</div><div>Sex</div><div>Sáb</div>
          </div>

          <div className="grid grid-cols-7 gap-1">
            {days.map(d => {
              const eventsOnDay = events.filter(e => new Date(e.date).toDateString() === d.toDateString());
              return (
                <div 
                  key={d.toString()} 
                  className={`h-24 sm:h-32 p-2 border border-gray-700 rounded-lg ${d.getMonth() !== currentDate.getMonth() ? 'bg-gray-900/50 text-gray-500' : 'bg-gray-800'}`}
                >
                  <div className={`font-bold ${isToday(d) ? 'text-primary' : ''}`}>{d.getDate()}</div>
                  <div className="mt-1 space-y-1 overflow-y-auto max-h-20">
                      {eventsOnDay.map(event => (
                          <button key={event.id} onClick={() => openDetailsModal(event)} className="w-full text-left text-xs p-1 bg-primary/30 hover:bg-primary/50 rounded transition-colors truncate">
                              {event.name}
                          </button>
                      ))}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      ) : (
        <div className="space-y-8">
            <div>
                <h2 className="text-2xl font-semibold text-white mb-4 border-b border-gray-700 pb-2">Próximos Eventos</h2>
                <div className="space-y-3">
                    {upcomingEvents.length > 0 ? (
                        upcomingEvents.map(event => (
                            <EventListItem key={event.id} event={event} onDetailsClick={openDetailsModal} />
                        ))
                    ) : (
                        <div className="bg-gray-800 p-4 rounded-lg text-center text-gray-400">Nenhum evento futuro agendado.</div>
                    )}
                </div>
            </div>
            <div>
                <h2 className="text-2xl font-semibold text-white mb-4 border-b border-gray-700 pb-2">Eventos Passados</h2>
                <div className="space-y-3">
                     {pastEvents.length > 0 ? (
                        pastEvents.map(event => (
                            <EventListItem key={event.id} event={event} onDetailsClick={openDetailsModal} />
                        ))
                    ) : (
                        <div className="bg-gray-800 p-4 rounded-lg text-center text-gray-400">Nenhum evento no histórico.</div>
                    )}
                </div>
            </div>
        </div>
      )}
      
      {isEventFormOpen && (
        <EventForm
          event={selectedEvent}
          teams={teams}
          members={members}
          onSave={saveEvent}
          onClose={() => setIsEventFormOpen(false)}
        />
      )}
      
      {isDetailsModalOpen && selectedEvent && (
        <EventDetailsModal
          event={selectedEvent}
          members={members}
          teams={teams}
          onClose={() => setIsDetailsModalOpen(false)}
          onEdit={openEventForm}
        />
      )}

    </div>
  );
};