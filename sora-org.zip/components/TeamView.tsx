import React, { useState, useMemo } from 'react';
import type { Member, Team } from '../types';
import { TeamForm } from './TeamForm';
import { AddIcon } from './icons';

interface TeamViewProps {
  teams: (Team & { wins: number; losses: number; })[];
  members: Member[];
  saveTeam: (team: Omit<Team, 'id'> & { id?: string }) => void;
  deleteTeam: (teamId: string) => void;
}

export const TeamView: React.FC<TeamViewProps> = ({ teams, members, saveTeam, deleteTeam }) => {
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);

  const memberMap = useMemo(() => {
    return new Map(members.map(member => [member.id, member.nickname]));
  }, [members]);

  const openFormForEdit = (team: Team) => {
    setSelectedTeam(team);
    setIsFormOpen(true);
  };

  const openFormForNew = () => {
    setSelectedTeam(null);
    setIsFormOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4">
        <h1 className="text-3xl font-bold text-white">Gerenciamento de Times</h1>
        <button
          onClick={openFormForNew}
          className="w-full md:w-auto flex items-center justify-center gap-2 bg-primary hover:bg-primary-hover text-white font-bold py-2 px-4 rounded-lg transition-colors"
        >
          <AddIcon />
          Adicionar Time
        </button>
      </div>

      <div className="overflow-x-auto bg-gray-800 rounded-lg shadow-md">
        <table className="min-w-full divide-y divide-gray-700">
          <thead className="bg-gray-700/50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Nome do Time</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider hidden md:table-cell">Capitão</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Membros</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Resultado (V/D)</th>
              <th scope="col" className="relative px-6 py-3"><span className="sr-only">Ações</span></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-700">
            {teams.map(team => (
              <tr key={team.id} className="hover:bg-gray-700/50 transition-colors">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-white">{team.name}</div>
                  <div className="text-xs text-gray-400 md:hidden mt-1">Capitão: {memberMap.get(team.captainId) || 'N/D'}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300 hidden md:table-cell">
                  {memberMap.get(team.captainId) || 'Não definido'}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">
                  {team.memberIds.length}
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                  <span className="text-green-400">{team.wins}</span> / <span className="text-red-400">{team.losses}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  <button onClick={() => openFormForEdit(team)} className="text-primary hover:text-primary-hover">Editar</button>
                </td>
              </tr>
            ))}
             {teams.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-center py-8 text-gray-400">
                    Nenhum time cadastrado.
                  </td>
                </tr>
              )}
          </tbody>
        </table>
      </div>
      
      {isFormOpen && (
        <TeamForm
          team={selectedTeam}
          members={members}
          onSave={saveTeam}
          onClose={() => setIsFormOpen(false)}
          onDelete={deleteTeam}
        />
      )}
    </div>
  );
};
