export enum Lane {
  Top = 'Top',
  Jungle = 'Jungle',
  Mid = 'Mid',
  ADC = 'ADC',
  Support = 'Support',
  Flex = 'Flex',
}

export enum MemberRole {
  Founder = 'Fundador',
  Moderator = 'Moderador',
  Administrator = 'Administrador',
  Captain = 'Capitão',
  Member = 'Membro',
}

export enum MemberStatus {
  Active = 'Ativo',
  Inactive = 'Inativo',
  Left = 'Saiu',
}

export interface Infraction {
  id: string;
  date: string;
  description: string;
}

export interface Member {
  id:string;
  fullName: string;
  nickname: string;
  role: MemberRole;
  mainLane: Lane;
  secondaryLane?: Lane;
  characters: string[];
  discordNick: string;
  contact: string;
  birthDate: string;
  joinDate: string;
  status: MemberStatus;
  exitReason?: string;
  exitDate?: string; // New field
  infractions: Infraction[];
  complaintsMade: string[]; // New field
  complaintsReceived: string[]; // New field
  notes?: string;
}

export enum EventType {
  Training = 'Treinamento',
  Scrim = 'Scrim',
  Meeting = 'Reunião',
  Tournament = 'Torneio',
  Other = 'Outro',
}

export enum EventStatus {
  Planned = 'Planejado',
  Completed = 'Concluído',
  Canceled = 'Cancelado',
}

export enum EventResult {
  Victory = 'Vitória',
  Defeat = 'Derrota',
}

export interface GuildEvent {
  id: string;
  name: string;
  date: string;
  type: EventType;
  description: string;
  status: EventStatus;
  organizerIds: string[];
  participantIds: string[];
  participatingTeamId?: string;
  result?: EventResult;
}

export enum ActivityType {
    MemberJoined = 'Membro Entrou',
    MemberLeft = 'Membro Saiu',
    EventCreated = 'Evento Criado',
    EventCompleted = 'Evento Concluído',
    MemberUpdated = 'Membro Atualizado',
    ComplaintFiled = 'Denúncia Registrada',
    TeamCreated = 'Time Criado',
    TeamUpdated = 'Time Atualizado',
}

export interface ActivityLog {
    id: string;
    date: string;
    type: ActivityType;
    description: string;
}

export interface Complaint {
  id: string;
  date: string;
  reporterId: string;
  accusedId: string;
  description: string;
}

export interface Team {
  id: string;
  name: string;
  captainId: string;
  memberIds: string[];
}

export type Page = 'Dashboard' | 'Membros' | 'Times' | 'Eventos' | 'Denúncias' | 'Configurações';